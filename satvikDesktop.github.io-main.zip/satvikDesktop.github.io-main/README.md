
![](https://img.shields.io/github/issues/satvikDesktop/satvikDesktop.github.io?color=purple&label=issues&logoColor=black&style=flat-square) 
![](https://img.shields.io/github/forks/satvikDesktop/satvikDesktop.github.io)
# satvik.ninja
## Description
#### Portfolio website created using `HTML` , `CSS` and `Javascript`
## Screenshots

<img src="https://www.linkpicture.com/q/safari-browser-mac-setapp.avif_1.png" width="" height="" /> 
<img src="https://www.linkpicture.com/q/01screenshot-entire-webpage-ios-e1615988874558.jpg_1.png" width="" height="" />

## Credits 
### Background :
Pixel art by [waneella](https://twitter.com/waneella_)



### Fonts:
- [Roboto Mono](https://fonts.google.com/specimen/Roboto+Mono)
- [Jet Brains Mono ](https://fonts.google.com/specimen/JetBrains+Mono)

### Icons:
 All social icons from [Flaticon.com](https://www.flaticon.com/)